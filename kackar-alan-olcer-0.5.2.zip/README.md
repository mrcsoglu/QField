# Kaçkar Poligon Alan Ölçer — v0.5.2

QField uygulama eklentisi. Poligonlara dokunarak alanı m² ve ha olarak ölçer; çakışan nesneler arasından seçim yaptırır ve seçilen geometrinin sınırını vurgular.

## v0.5.2 — QGIS sorgulama izinleriyle uyum

- **Yalnızca QGIS projesinde Tanımlanabilir (Identifiable) olarak işaretli görünür poligonlar ölçülür.**
- İşareti kaldırılmış poligon katmanları çoklu seçim listesinde de görünmez.
- İzinler her dokunuşta yeniden okunur; seçim sırasında da tekrar kontrol edilir.
- Kullanıcının izin ayarları okunamazsa gizli bir katmanı yanlışlıkla ölçmek yerine uyarı verilir.
- v0.5.1'de çalışan vurgulama, sade koyu tema, çoklu seçim, tek EPSG:6933 yüzölçümü ve m²/ha sonuçları korunmuştur.

## İzinleri nereden yöneteceksin?

QGIS masaüstünde **Proje > Özellikler > Veri Kaynakları > Tanımlanabilir (Identifiable)**.

- Alanını ölçmek istediğin poligon katmanlarının işaretini **aç**.
- Alan ölçerde gösterilmesini istemediğin katmanların işaretini **kapat**.
- QGIS projesini kaydedip QField'da güncel projeyi tekrar aç.

Bu ayar katmanın haritada **görünürlük** özelliğinden farklıdır. Görünür olup sorgulanması kapalı olan katmanlar da alan ölçerde gösterilmez. Aynı isimli katmanlar ID ile ayırt edilir.

## Alan hesabı

Eklenti `area(transform($geometry, @layer_crs, 'EPSG:6933'))` kullanır. Geometriyi değiştirmez; resmî tapu beyan alanı yerine geçmez.

## GitHub Releases / QField kurulum

`kackar-alan-olcer-0.5.2.zip` dosyasını GitHub Releases'a yükle; QField'da eski eklenti yerine bu sürümü kur. ZIP'in kökünde `main.qml`, `metadata.txt`, `README.md` bulunur.

**Sınama:** Dosya yapısı ve izin filtresi statik kontrollerden geçirilmiştir. iPhone/QField cihazında henüz çalıştırılarak doğrulanmamıştır. 
