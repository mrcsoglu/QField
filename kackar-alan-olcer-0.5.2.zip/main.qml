import QtQuick
import QtQuick.Controls
import org.qfield
import org.qfield.gui
import org.qgis
import Theme

// Kaçkar Poligon Alan Ölçer 0.5.2
// - Görünür poligon katmanları ve çakışan poligonlar listesi korunur.
// - Seçili geometri geçici animasyon yerine kalıcı QfGeometryRenderer ile çizilir.
// - WGS84/EPSG:6933 eş-alan üzerinden tek yüzölçümü (m² + ha) hesaplanır.
// - Veri kaynağına herhangi bir geometri/öznitelik yazılmaz.
Item {
    id: plugin
    objectName: "kackarPolygonAreaPlugin"

    property var mainWindow: iface.mainWindow()
    property var canvas: iface.mapCanvas()
    property var pointHandler: iface.findItemByObjectName("pointHandler")

    property bool measurementMode: false
    property bool resultVisible: false
    property bool candidatesVisible: false
    property bool resultHasArea: false
    property var candidates: []
    property var selectedCandidate: null
    property int totalExamined: 0
    property int maxCandidates: 100
    property string handlerId: "kackar_polygon_area_v052"
    property string resultMessage: ""
    property string resultLayer: ""
    property string resultName: ""
    property string resultHectares: ""
    property string resultSquareMeters: ""
    property string highlightStatus: ""

    ExpressionEvaluator {
        id: evaluator
        project: qgisProject
        mapSettings: plugin.canvas.mapSettings
    }

    function formatTR(value, decimals) {
        const parts = Number(value).toFixed(decimals).split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        return parts.join(",");
    }

    // QGIS: Proje > Özellikler > Veri Kaynakları > Tanımlanabilir.
    // QgsProject.nonIdentifiableLayers Qt özelliği, QgsMapLayer.Identifiable
    // bayrağı kapalı olan katmanların ID listesini anlık olarak döndürür.
    // İzin bilgisi erişilemezse ölçme yapmayız (kapalı varsayım).
    function getBlockedLayerIds() {
        if (!qgisProject)
            throw new Error("Proje bulunamadı.");
        const ids = qgisProject.nonIdentifiableLayers;
        if (ids === undefined || ids === null || typeof ids.length !== "number")
            throw new Error("Katman sorgulama izinleri okunamadı. QField sürümünü kontrol edin.");
        return ids;
    }

    function canMeasureLayer(layer, blockedIds) {
        if (!layer || layer.id === undefined || layer.id === null)
            return false;
        const id = String(layer.id);
        if (!id.length)
            return false;
        for (let i = 0; i < blockedIds.length; ++i) {
            if (String(blockedIds[i]) === id)
                return false;
        }
        return true;
    }

    function displayNameFor(layer, feature) {
        try {
            const name = FeatureUtils.displayName(layer, feature);
            if (name !== null && name !== undefined) {
                const cleaned = String(name).trim();
                if (cleaned.length && cleaned.toUpperCase() !== "NULL")
                    return cleaned;
            }
        } catch (e) {
            console.warn("Alan Ölçer - ad okunamadı: " + e);
        }
        return "Nesne #" + String(feature.id);
    }

    // Vurgulama doğrudan QField'ın harita çizicisi üzerinde sürekli kalır.
    // Geometriyi güvenli biçimde QVariant -> WKT -> QgsGeometry olarak aktarırız.
    function clearHighlight() {
        selectedCandidate = null;
        highlightStatus = "";
        try { outerGlow.geometryWrapper.clear(); } catch (e1) { console.warn(e1); }
        try { selectionOutline.geometryWrapper.clear(); } catch (e2) { console.warn(e2); }
    }

    function closePanels() {
        resultVisible = false;
        candidatesVisible = false;
        clearHighlight();
    }

    function showMessage(message) {
        clearHighlight();
        resultHasArea = false;
        resultMessage = message;
        resultVisible = true;
        candidatesVisible = false;
    }

    function drawSelectedGeometry() {
        if (!selectedCandidate)
            return;
        try {
            evaluator.layer = selectedCandidate.layer;
            evaluator.feature = selectedCandidate.feature;
            // WKT, QML tarafında QGIS geometry QVariant türü dönüşüm
            // belirsizliğini giderir. 10 haneli duyarlık UTM için yeterlidir.
            const wkt = evaluator.evaluate("geom_to_wkt($geometry, 10)");
            if (!wkt || typeof wkt !== "string")
                throw new Error("Poligon WKT olarak okunamadı.");
            const geom = GeometryUtils.createGeometryFromWkt(wkt);
            if (!geom)
                throw new Error("Poligon geometrisi oluşturulamadı.");
            const layerCrs = selectedCandidate.layer.crs;
            // İki çizici de kendi geometryWrapper'ına sahiptir.
            // Önce CRS, sonra geometri atanır.
            outerGlow.geometryWrapper.crs = layerCrs;
            selectionOutline.geometryWrapper.crs = layerCrs;
            outerGlow.geometryWrapper.qgsGeometry = geom;
            selectionOutline.geometryWrapper.qgsGeometry = geom;
            highlightStatus = "";
        } catch (error) {
            highlightStatus = "Sınır vurgulanamadı: " + String(error);
            console.warn("Alan Ölçer: " + highlightStatus);
        }
    }

    function selectCandidate(index) {
        if (index < 0 || index >= candidates.length)
            return;
        const selected = candidates[index];
        // Seçim penceresi açıkken bile proje izinleri değişmiş olabilir.
        try {
            if (!canMeasureLayer(selected.layer, getBlockedLayerIds())) {
                showMessage("Bu katman sorgulamaya kapalı.");
                return;
            }
        } catch (permissionError) {
            showMessage(String(permissionError));
            return;
        }
        clearHighlight();
        selectedCandidate = selected;
        resultLayer = String(selected.layer.name);
        resultName = selected.name;
        resultHectares = formatTR(selected.area / 10000.0, 2);
        resultSquareMeters = formatTR(selected.area, 2);
        resultHasArea = true;
        resultMessage = "";
        candidatesVisible = false;
        resultVisible = true;
        drawSelectedGeometry();
    }

    function handleMapTap(point, type, interactionType) {
        if (!measurementMode || interactionType !== "clicked")
            return false;

        resultVisible = false;
        candidatesVisible = false;
        clearHighlight();

        const matches = [];
        let polygonLayers = 0;
        let examined = 0;
        let lastError = "";
        try {
            const settings = canvas.mapSettings;
            const blockedLayerIds = getBlockedLayerIds();
            const layers = settings.layers;
            if (!layers || layers.length === 0) {
                showMessage("Görünür katman bulunamadı.");
                return true;
            }

            const tl = settings.screenToCoordinate(Qt.point(point.x - 4, point.y - 4));
            const br = settings.screenToCoordinate(Qt.point(point.x + 4, point.y + 4));
            const touchRect = GeometryUtils.createRectangleFromPoints(tl, br);

            for (let i = 0; i < layers.length; ++i) {
                const layer = layers[i];
                if (!layer || typeof layer.geometryType !== "function" || layer.geometryType() !== 2)
                    continue;
                // Haritada açık olması tek başına izin anlamına gelmez.
                // QField'ın kendi bilgi sorgusunda kapattığın katmanları atla.
                if (!canMeasureLayer(layer, blockedLayerIds))
                    continue;
                ++polygonLayers;

                let it = null;
                try {
                    const layerRect = GeometryUtils.reprojectRectangle(
                        touchRect, settings.destinationCrs, layer.crs);
                    it = LayerUtils.createFeatureIteratorFromRectangle(layer, layerRect);
                    if (!it)
                        continue;
                    evaluator.layer = layer;
                    while (it.hasNext() && matches.length < maxCandidates) {
                        const feature = it.next();
                        ++examined;
                        evaluator.feature = feature;
                        // WGS84 ellipsoidi esaslı eş-alan (EPSG:6933).
                        // Düzlemsel UTM alanı ayrıca gösterilmez.
                        const area = Number(evaluator.evaluate(
                            "area(transform($geometry, @layer_crs, 'EPSG:6933'))"));
                        if (!isFinite(area) || area <= 0) {
                            lastError = "Alan hesaplanamadı: " + String(layer.name) +
                                        " / #" + String(feature.id) +
                                        " (EPSG:6933 dönüşümünü kontrol edin)";
                            continue;
                        }

                        matches.push({
                            layer: layer,
                            feature: feature,
                            name: displayNameFor(layer, feature),
                            layerPosition: i,
                            area: area
                        });
                    }
                } catch (layerError) {
                    lastError = String(layer.name) + ": " + layerError;
                    console.warn("Alan Ölçer - katman işlenemedi: " + lastError);
                } finally {
                    // QField API, iterator.close() çağrılmasını gerektiriyor.
                    if (it && typeof it.close === "function")
                        it.close();
                }
                if (matches.length >= maxCandidates)
                    break;
            }

            totalExamined = examined;
            // Katman sırasını koru, aynı katmandakiler küçükten büyüğe gelsin.
            matches.sort(function(a, b) {
                if (a.layerPosition !== b.layerPosition)
                    return a.layerPosition - b.layerPosition;
                return a.area - b.area;
            });
            candidates = matches;

            if (matches.length === 1) {
                selectCandidate(0);
            } else if (matches.length > 1) {
                candidatesVisible = true;
            } else if (polygonLayers === 0) {
                showMessage("Ölçülebilir poligon katmanı yok.");
            } else if (lastError.length) {
                showMessage("Alan hesaplanamadı: " + lastError);
            } else {
                showMessage("Dokunma çevresinde poligon bulunamadı (" +
                            polygonLayers + " katman, " + examined + " aday).");
            }
        } catch (e) {
            console.warn("Alan Ölçer - dokunma hatası: " + e);
            showMessage("Dokunma işlenemedi: " + e);
        }
        // Ölçme modunda QField'ın alttaki normal seçim ekranını açma.
        return true;
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(measureButton);
        if (pointHandler && pointHandler.registerHandler) {
            pointHandler.registerHandler(handlerId, function(point, type, interactionType) {
                return plugin.handleMapTap(point, type, interactionType);
            }, 1000);
        } else {
            mainWindow.displayToast("Alan Ölçer: Harita dokunma arayüzü bulunamadı.");
        }
    }

    Component.onDestruction: {
        closePanels();
        if (pointHandler && pointHandler.deregisterHandler)
            pointHandler.deregisterHandler(handlerId);
    }

    // Harita üstü görünüm: sürekli kalan dolgu ve belirgin çift sınır.
    // QfGeometryRenderer kendi QgsGeometryWrapper'ı ile çizim yapar;
    // native QField geometri işaretleyicisinin süreli animasyonuna bağlı değildir.
    QfGeometryRenderer {
        id: outerGlow
        objectName: "kackarAreaGlow"
        parent: plugin.canvas
        anchors.fill: parent
        z: 8900
        visible: plugin.measurementMode && plugin.resultVisible && plugin.resultHasArea
        mapSettings: plugin.canvas.mapSettings
        color: "#ff9800"
        opacity: 0.42
        lineWidth: 13
    }

    QfGeometryRenderer {
        id: selectionOutline
        objectName: "kackarAreaOutline"
        parent: plugin.canvas
        anchors.fill: parent
        z: 8901
        visible: plugin.measurementMode && plugin.resultVisible && plugin.resultHasArea
        mapSettings: plugin.canvas.mapSettings
        color: "#fff000"
        lineWidth: 4.5
        opacity: 1.0
    }

    QfToolButton {
        id: measureButton
        bgcolor: plugin.measurementMode ? Theme.mainColor : Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_info_white_24dp")
        iconColor: plugin.measurementMode ? "white" : Theme.mainColor
        round: true
        onClicked: {
            plugin.measurementMode = !plugin.measurementMode;
            plugin.closePanels();
            plugin.mainWindow.displayToast(plugin.measurementMode
                ? "Alan ölçme açık"
                : "Alan ölçme kapalı");
        }
    }

    // Çakışan poligon seçim paneli: QField'ın koyu arayüzüyle uyumlu,
    // yardımcı yazısız ve ince, nötr çerçeveli sade liste.
    Rectangle {
        id: choicesPanel
        parent: plugin.mainWindow.contentItem
        visible: plugin.candidatesVisible
        z: 10000
        x: (parent.width - width) / 2
        y: parent.height - height - 75
        width: Math.min(parent.width - 24, 420)
        height: Math.min(parent.height * 0.58,
                         56 + Math.min(plugin.candidates.length, 6) * 58)
        radius: 13
        color: "#24323b"
        border.color: "#485963"
        border.width: 1

        Column {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Item {
                width: parent.width
                height: 29

                Text {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Alan seç (" + plugin.candidates.length + ")"
                    color: "#f1f5f7"
                    font.bold: true
                    font.pixelSize: 17
                    width: parent.width - 43
                    elide: Text.ElideRight
                }
                Rectangle {
                    id: closeChoicesButton
                    width: 34
                    height: 29
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    color: closeChoicesArea.pressed ? "#41525c" : "transparent"
                    radius: 7
                    Text {
                        anchors.centerIn: parent
                        text: "×"
                        color: "#d6e0e5"
                        font.pixelSize: 24
                    }
                    MouseArea {
                        id: closeChoicesArea
                        anchors.fill: parent
                        onClicked: plugin.closePanels()
                    }
                }
            }
            Flickable {
                width: parent.width
                height: Math.max(0, parent.height - 47)
                clip: true
                contentWidth: width
                contentHeight: choiceRows.height
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: choiceRows
                    width: parent.width
                    spacing: 5
                    Repeater {
                        model: plugin.candidates
                        delegate: Rectangle {
                            required property int index
                            required property var modelData
                            width: choiceRows.width
                            height: 53
                            color: chooseArea.pressed ? "#4b5e68" : "#354751"
                            border.color: "#465a64"
                            border.width: 1
                            radius: 8
                            Column {
                                anchors.fill: parent
                                anchors.margins: 7
                                spacing: 2
                                Text {
                                    text: modelData.layer.name + " · " + modelData.name
                                    color: "#f5f7f8"
                                    font.pixelSize: 13
                                    font.bold: true
                                    width: parent.width
                                    elide: Text.ElideRight
                                }
                                Text {
                                    text: plugin.formatTR(modelData.area / 10000, 2) + " ha  ·  " +
                                          plugin.formatTR(modelData.area, 2) + " m²"
                                    color: Theme.mainColor
                                    font.pixelSize: 12
                                    width: parent.width
                                    elide: Text.ElideRight
                                }
                            }
                            MouseArea {
                                id: chooseArea
                                anchors.fill: parent
                                onClicked: plugin.selectCandidate(index)
                            }
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        id: resultCard
        parent: plugin.mainWindow.contentItem
        visible: plugin.resultVisible
        z: 10000
        width: Math.min(parent.width - 24, 420)
        height: plugin.resultHasArea ? (plugin.highlightStatus.length ? 175 : 146) : 104
        x: (parent.width - width) / 2
        y: parent.height - height - 75
        radius: 13
        color: "#24323b"
        border.color: "#485963"
        border.width: 1

        Column {
            anchors.fill: parent
            anchors.margins: 13
            spacing: 5
            Text {
                text: plugin.resultHasArea ? plugin.resultLayer : "ALAN ÖLÇER"
                color: "#d8e3e8"
                font.pixelSize: 13
                font.bold: true
                width: parent.width
                elide: Text.ElideRight
            }
            Text {
                text: plugin.resultHasArea ? plugin.resultName : plugin.resultMessage
                color: "#ffffff"
                font.pixelSize: 15
                font.bold: true
                width: parent.width
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
            }
            Text {
                visible: plugin.resultHasArea
                text: plugin.resultHectares + " ha"
                color: Theme.mainColor
                font.pixelSize: 25
                font.bold: true
            }
            Text {
                visible: plugin.resultHasArea
                text: plugin.resultSquareMeters + " m²"
                color: "#d8e3e8"
                font.pixelSize: 14
            }
            Text {
                visible: plugin.resultHasArea && plugin.highlightStatus.length > 0
                text: plugin.highlightStatus
                color: "#d8e3e8"
                font.pixelSize: 11
                width: parent.width
                wrapMode: Text.WordWrap
            }
        }
        MouseArea {
            anchors.fill: parent
            onClicked: plugin.closePanels()
        }
    }
}
