QField - Konum Bilgi Kartı v0.1.1

Bu eklenti QField'ın var olan Konumlandırma bilgi panelini yeniden yazmaz.
Kendi küçük bilgi kartını açar. Aynı anda iki panel çıkmasın diye QField'da
"Konum bilgilerini göster" seçeneğini kapatmanız önerilir.

KURULUM
- QField > Ayarlar > Eklentiler > URL'den eklenti yükle.
- Verilen doğrudan HTTPS ZIP bağlantısını girin.
- Eklentiyi etkinleştirin; eklenti araç çubuğundaki bilgi simgesine basın.

GÖSTERİLEN VERİLER
- Otomatik WGS84 UTM dilimi ve enlem bandı (37T gibi).
- Koordinat, tek satırda 37T 000000 0000000 biçiminde (doğu 6, kuzey 7 hane).
- Varsa GPS yatay doğruluğu ve yüksekliği.
- Kopyala aynı koordinat metnini alır: '37T 627693 4542754'.

NOTLAR
- GPS izinleri ve geçerli konum gereklidir.
- UTM yalnızca 80°G - 84°K enlemleri arasında geçerlidir.
- Mevcut QField arayüzü, katmanlar veya proje dosyaları değiştirilmez.
- Bu sürüm QML kaynak incelemesinden geçirilmiştir; iPhone üzerinde denenmemiştir.
