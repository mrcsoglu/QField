import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.core
import org.qfield.gui

// QField application plugin. The built-in positioning panel is not modified.
Item {
    id: root
    objectName: "konumBilgiKartiPlugin"

    property var positioning: iface.positioning()
    property bool cardOpen: false
    property bool gpsReady: false
    property string utmLabel: "—"
    property string eastText: "—"
    property string northText: "—"
    property string accuracyText: ""
    property string elevationText: ""
    property bool accuracyAvailable: false
    property bool elevationAvailable: false
    property string clipboardText: ""

    function utmZone(lat, lon) {
        var normalized = Math.max(-180, Math.min(179.999999999, lon));
        var z = Math.floor((normalized + 180) / 6) + 1;
        // Standard UTM exceptions for Norway and Svalbard.
        if (lat >= 56 && lat < 64 && lon >= 3 && lon < 12) return 32;
        if (lat >= 72 && lat < 84 && lon >= 0 && lon < 42) {
            if (lon < 9) return 31;
            if (lon < 21) return 33;
            if (lon < 33) return 35;
            return 37;
        }
        return Math.min(60, Math.max(1, z));
    }

    function utmBand(lat) {
        if (lat < -80 || lat > 84) return "";
        var bands = "CDEFGHJKLMNPQRSTUVWX";
        var index = Math.max(0, Math.min(19, Math.floor((lat + 80) / 8)));
        return bands.charAt(index);
    }

    function resetPosition() {
        gpsReady = false;
        utmLabel = "—";
        eastText = "—";
        northText = "—";
        accuracyAvailable = false;
        elevationAvailable = false;
        accuracyText = "";
        elevationText = "";
        clipboardText = "";
    }

    function refreshPosition() {
        var source = positioning;
        if (!source || !source.active || !source.positionInformation) {
            resetPosition();
            return;
        }
        var info = source.positionInformation;
        if (!info.latitudeValid || !info.longitudeValid) {
            resetPosition();
            return;
        }
        var lat = Number(info.latitude);
        var lon = Number(info.longitude);
        if (!isFinite(lat) || !isFinite(lon) || lat < -80 || lat > 84 || lon < -180 || lon > 180) {
            resetPosition();
            return;
        }
        try {
            var zone = utmZone(lat, lon);
            var band = utmBand(lat);
            var epsg = (lat >= 0 ? 32600 : 32700) + zone;
            var crs = QfCoordinateReferenceSystemUtils.fromDescription("EPSG:" + epsg);
            var point = QfGeometryUtils.reprojectPoint(
                QfGeometryUtils.point(lon, lat),
                QfCoordinateReferenceSystemUtils.wgs84Crs(),
                crs
            );
            var x = Number(point.x);
            var y = Number(point.y);
            if (!isFinite(x) || !isFinite(y)) {
                resetPosition();
                return;
            }
            utmLabel = "WGS84 · UTM " + zone + band;
            eastText = String(Math.round(x));
            northText = String(Math.round(y));
            clipboardText = zone + band + " " + eastText + " " + northText;
            gpsReady = true;

            var acc = Number(info.hacc);
            accuracyAvailable = Boolean(info.haccValid) && isFinite(acc) && acc >= 0;
            accuracyText = accuracyAvailable ? acc.toFixed(acc < 10 ? 1 : 0) + " m" : "";

            var alt = Number(info.elevation);
            elevationAvailable = Boolean(info.elevationValid) && isFinite(alt);
            elevationText = elevationAvailable ? alt.toFixed(1) + " m" : "";
        } catch (err) {
            console.warn("Konum Bilgi Karti CRS hatasi: " + err);
            resetPosition();
        }
    }

    function copyCoordinate() {
        if (!gpsReady || !clipboardText) return;
        platformUtilities.copyTextToClipboard(clipboardText);
        iface.mainWindow().displayToast("UTM koordinatı kopyalandı");
    }

    Connections {
        target: root.positioning
        ignoreUnknownSignals: true
        function onPositionInformationChanged() { root.refreshPosition(); }
        function onActiveChanged() { root.refreshPosition(); }
    }

    Timer {
        interval: 2000
        running: root.cardOpen
        repeat: true
        onTriggered: root.refreshPosition()
    }

    QfToolButton {
        id: openButton
        iconSource: QfTheme.getThemeVectorIcon("ic_info_white_24dp")
        iconColor: QfTheme.toolButtonColor
        bgcolor: QfTheme.toolButtonBackgroundColor
        round: true
        onClicked: {
            root.cardOpen = !root.cardOpen;
            if (root.cardOpen) root.refreshPosition();
        }
    }

    Rectangle {
        id: locationCard
        parent: iface.mainWindow().contentItem
        z: 1000
        visible: root.cardOpen
        width: Math.min(parent.width - 24, 390)
        height: cardContents.implicitHeight + 24
        radius: 13
        color: QfTheme.mainBackgroundColor
        border.color: QfTheme.secondaryTextColor
        border.width: 1
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Math.max(96, iface.mainWindow().sceneBottomMargin + 80)

        ColumnLayout {
            id: cardContents
            anchors.fill: parent
            anchors.margins: 12
            spacing: 9

            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: "Konumum"
                        font.bold: true
                        font.pixelSize: 16
                        color: QfTheme.mainTextColor
                    }
                    Text {
                        text: root.gpsReady ? root.utmLabel : "GPS konumu bekleniyor"
                        font.pixelSize: 11
                        color: QfTheme.secondaryTextColor
                    }
                }
                Button {
                    text: "Kopyala"
                    enabled: root.gpsReady
                    onClicked: root.copyCoordinate()
                }
                Button {
                    text: "×"
                    implicitWidth: 42
                    onClicked: root.cardOpen = false
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Rectangle {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    Layout.preferredHeight: 66
                    radius: 9
                    color: QfTheme.groupBoxBackgroundColor
                    Column {
                        anchors.fill: parent
                        anchors.margins: 9
                        spacing: 5
                        Text {
                            text: "Doğu (X)"
                            color: QfTheme.secondaryTextColor
                            font.pixelSize: 11
                        }
                        Text {
                            text: root.eastText
                            color: QfTheme.mainTextColor
                            font.pixelSize: 18
                            font.bold: true
                        }
                    }
                }
                Rectangle {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    Layout.preferredHeight: 66
                    radius: 9
                    color: QfTheme.groupBoxBackgroundColor
                    Column {
                        anchors.fill: parent
                        anchors.margins: 9
                        spacing: 5
                        Text {
                            text: "Kuzey (Y)"
                            color: QfTheme.secondaryTextColor
                            font.pixelSize: 11
                        }
                        Text {
                            text: root.northText
                            color: QfTheme.mainTextColor
                            font.pixelSize: 18
                            font.bold: true
                        }
                    }
                }
            }

            RowLayout {
                visible: root.accuracyAvailable || root.elevationAvailable
                Layout.fillWidth: true
                spacing: 14
                Text {
                    visible: root.accuracyAvailable
                    text: "Yatay doğruluk: " + root.accuracyText
                    font.pixelSize: 12
                    color: QfTheme.mainTextColor
                }
                Text {
                    visible: root.elevationAvailable
                    text: "Yükseklik: " + root.elevationText
                    font.pixelSize: 12
                    color: QfTheme.mainTextColor
                }
            }
            Text {
                visible: !root.gpsReady
                Layout.fillWidth: true
                text: "QField'da konumlandırmayı açın ve GPS verisini bekleyin."
                font.pixelSize: 11
                color: QfTheme.secondaryTextColor
                wrapMode: Text.WordWrap
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(openButton);
        refreshPosition();
        console.log("Konum Bilgi Karti v0.1.0 etkinlestirildi");
    }
}
