QField — Koordinat ve Hedef (deneme 0.1.0)

KURULUM
QField > Ayarlar > Eklentiler > URL'den eklenti yükle.
Bu ZIP dosyasını herkese erişilebilir bir HTTPS adresine yükleyip doğrudan ZIP bağlantısını girin.
ZIP içeriğinde main.qml ve metadata.txt kök dizindedir.

KULLANIM
• Haritadaki herhangi bir boş noktaya tek dokun: UTM (WGS84) koordinatı alt bantta görünür.
• Kopyala: dokunulan noktanın koordinatını kopyalar.
• Hedef: dokunulan noktayı hedef seçer.
• Araç çubuğunda yer işareti: koordinat kutusu açılır.
• Örnek: 40.87858862, 40.92766640
• Örnek: 37T 663840 4525972
• Örnek: EPSG:32637 663840 4525972
• Örnek: 40°52′42.9″N 40°55′39.6″E
• Dilimsiz UTM: 663840 4525972 (37N varsayılır, yanlışsa dilim yazılmalıdır).
• Hedef menüsü: GPS aktifken hedefe kuş uçuşu mesafe ve kuzeye göre yön görünür.

UYARILAR
• GPS mesafe/yön, yol tarifi değildir ve arazi güvenliği için tek kaynak olmamalıdır.
• Dokunulan noktanın QField özellik sorgulaması normal biçimde çalışmaya devam eder.
• Ondalık koordinatlar enlem, boylam sırasında kabul edilir; sonucun görüntüsünü kontrol edin.
• Bu sürüm statik kod kontrolü ve ayrıştırıcı testleri içindir; iPhone QField uygulamasında henüz test edilmedi.
• Telefon üzerinde sonuç alınmadan kararlı sürüm olarak değerlendirilmemelidir.
