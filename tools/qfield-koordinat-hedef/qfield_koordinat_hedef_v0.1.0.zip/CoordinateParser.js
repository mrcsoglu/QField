.pragma library

// Coordinates are interpreted on WGS 84.  Ambiguous UTM input is labelled,
// never silently treated as a uniquely identified location.
function parseNumber(value) {
    return Number(String(value).replace(',', '.'));
}

function bandToHemisphere(band) {
    return band >= 'N' ? 'N' : 'S';
}

function inBounds(lat, lon) {
    return isFinite(lat) && isFinite(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
}

function dmsValue(degrees, minutes, seconds, direction) {
    var d = parseNumber(degrees);
    var m = parseNumber(minutes);
    var s = parseNumber(seconds);
    if (m >= 60 || s >= 60) return NaN;
    return (d + m / 60 + s / 3600) * ((direction === 'S' || direction === 'W') ? -1 : 1);
}

function parse(text) {
    var s = String(text || '').trim().toUpperCase().replace(/\u2212/g, '-');
    if (!s) return { ok: false, error: 'Koordinat girin.' };

    // Degrees-minutes-seconds, e.g. 40°52′42.9″N 40°55′39.6″E
    var expression = /(\d{1,3})\s*[°º]\s*(\d{1,2})\s*['′’]\s*(\d{1,2}(?:[.,]\d+)?)\s*(?:["″”])?\s*([NSEW])/g;
    var found = [];
    var match;
    while ((match = expression.exec(s)) !== null) {
        found.push({ val: dmsValue(match[1], match[2], match[3], match[4]), dir: match[4] });
    }
    if (found.length === 2) {
        var latitude = NaN, longitude = NaN;
        for (var i = 0; i < found.length; ++i) {
            if (found[i].dir === 'N' || found[i].dir === 'S') latitude = found[i].val;
            if (found[i].dir === 'E' || found[i].dir === 'W') longitude = found[i].val;
        }
        if (inBounds(latitude, longitude)) return {ok: true, kind: 'geographic', lat: latitude, lon: longitude, note: 'Derece/dakika/saniye · WGS84'};
        return {ok: false, error: 'DMS koordinatı veya yön harfleri geçersiz.'};
    }

    // Explicit EPSG identifier, with UTM easting and northing.
    var epsg = s.match(/^EPSG\s*:\s*(326|327)(\d{2})\s*[,; :]+\s*(\d+(?:[.,]\d+)?)\s*[,; ]+\s*(\d+(?:[.,]\d+)?)\s*$/);
    if (epsg) {
        var z = Number(epsg[2]);
        if (z < 1 || z > 60) return {ok: false, error: 'UTM dilimi 1–60 arasında olmalı.'};
        return validateUtm(z, epsg[1] === '326' ? 'N' : 'S', parseNumber(epsg[3]), parseNumber(epsg[4]), 'EPSG:' + epsg[1] + epsg[2]);
    }

    // UTM zone + MGRS latitude band, e.g. 37T 663840 4525972.
    // The S latitude BAND does not mean southern hemisphere.
    var utm = s.match(/^(?:UTM\s+)?(\d{1,2})\s*([C-HJ-NP-X])\s*[,; ]+\s*(\d+(?:[.,]\d+)?)\s*[,; ]+\s*(\d+(?:[.,]\d+)?)\s*$/);
    if (utm) {
        var zone = Number(utm[1]);
        if (zone < 1 || zone > 60) return {ok: false, error: 'UTM dilimi 1–60 arasında olmalı.'};
        var band = utm[2];
        return validateUtm(zone, bandToHemisphere(band), parseNumber(utm[3]), parseNumber(utm[4]), zone + band + ' · WGS84 UTM', band);
    }

    // Decimal comma pairs separated by whitespace or semicolon (without comma as separator).
    var decimalComma = s.match(/^([+-]?\d{1,3},\d+)\s*[;\s]+\s*([+-]?\d{1,3},\d+)$/);
    if (decimalComma) {
        return decimalDegrees(parseNumber(decimalComma[1]), parseNumber(decimalComma[2]));
    }
    var normalized = s.replace(/[;,\s]+/g, ' ').trim().split(' ');
    if (normalized.length !== 2 || !normalized.every(function(p) { return /^[+-]?\d+(?:\.\d+)?$/.test(p); })) {
        return {ok: false, error: 'Biçim okunamadı. Örnek: 37T 663840 4525972 veya 40.8785, 40.9276'};
    }
    var a = Number(normalized[0]);
    var b = Number(normalized[1]);
    if (a >= 100000 && a <= 900000 && b >= 0 && b <= 10000000) {
        var candidate = validateUtm(37, 'N', a, b, 'Dilimsiz UTM: 37N varsayıldı');
        if (candidate.ok) candidate.ambiguous = true;
        return candidate;
    }
    return decimalDegrees(a, b);
}

function validateUtm(zone, hemi, easting, northing, note, band) {
    if (!isFinite(easting) || !isFinite(northing) || easting < 100000 || easting > 900000 || northing < 0 || northing > 10000000) {
        return {ok: false, error: 'UTM doğu/kuzey değerleri geçersiz.'};
    }
    return {ok: true, kind: 'utm', zone: zone, hemisphere: hemi, easting: easting, northing: northing, band: band || '', note: note, ambiguous: false};
}

function decimalDegrees(a, b) {
    if (inBounds(a, b)) return {ok: true, kind: 'geographic', lat: a, lon: b, note: 'Enlem, boylam · WGS84'};
    if (inBounds(b, a)) return {ok: true, kind: 'geographic', lat: b, lon: a, note: 'Boylam, enlem olarak yorumlandı'};
    return {ok: false, error: 'Enlem −90…90, boylam −180…180 arasında olmalı.'};
}

function utmZone(lat, lon) {
    var zone = Math.min(60, Math.max(1, Math.floor((lon + 180) / 6) + 1));
    // UTM special zones (Norway and Svalbard)
    if (lat >= 56 && lat < 64 && lon >= 3 && lon < 12) zone = 32;
    if (lat >= 72 && lat < 84) {
        if (lon >= 0 && lon < 9) zone = 31;
        else if (lon >= 9 && lon < 21) zone = 33;
        else if (lon >= 21 && lon < 33) zone = 35;
        else if (lon >= 33 && lon < 42) zone = 37;
    }
    return zone;
}

function latitudeBand(lat) {
    if (lat < -80 || lat > 84) return '';
    var letters = 'CDEFGHJKLMNPQRSTUVWX';
    return letters.charAt(Math.min(19, Math.floor((lat + 80) / 8)));
}

function formatUtm(zone, band, easting, northing) {
    return String(zone) + band + ' ' + Math.round(easting) + ' ' + Math.round(northing);
}

function meters(distance) {
    return distance >= 1000 ? (distance / 1000).toFixed(2) + ' km' : Math.round(distance) + ' m';
}

function distanceAndBearing(aLat, aLon, bLat, bLon) {
    var toRad = Math.PI / 180;
    var dLat = (bLat - aLat) * toRad;
    var dLon = (bLon - aLon) * toRad;
    var lat1 = aLat * toRad;
    var lat2 = bLat * toRad;
    var h = Math.sin(dLat/2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon/2) ** 2;
    var distance = 6371008.8 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0,1-h)));
    var y = Math.sin(dLon) * Math.cos(lat2);
    var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
    var bearing = ((Math.atan2(y, x) / toRad) + 360) % 360;
    return {distance: distance, bearing: bearing};
}

function direction(bearing) {
    var names = ['K', 'KD', 'D', 'GD', 'G', 'GB', 'B', 'KB'];
    return names[Math.floor((bearing + 22.5) / 45) % 8];
}
