import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.core
import org.qfield.gui
import "CoordinateParser.js" as Coordinates

Item {
    id: root
    objectName: "coordinateTargetPlugin"
    property var canvas: iface.mapCanvas()
    property bool tapEnabled: true
    property bool tappedValid: false
    property bool targetValid: false
    property real tappedLatitude: 0
    property real tappedLongitude: 0
    property real targetLatitude: 0
    property real targetLongitude: 0
    property string tappedUtm: ""
    property string targetUtm: ""
    property string targetDetails: "Hedef seçilmedi"
    property string navigationDetails: "Hedef belirlenince GPS mesafesi burada görünür."
    property string interpretation: ""

    function notify(text) {
        iface.mainWindow().displayToast(text);
    }

    function wgs84() {
        return QfCoordinateReferenceSystemUtils.wgs84Crs();
    }

    function projectedPoint(lon, lat, targetCrs) {
        return QfGeometryUtils.reprojectPoint(
                    QfGeometryUtils.point(lon, lat), wgs84(), targetCrs);
    }

    function geoFromProject(x, y) {
        var p = QfGeometryUtils.reprojectPoint(
                    QfGeometryUtils.point(x, y), qgisProject.crs, wgs84());
        return {lat: Number(p.y), lon: Number(p.x)};
    }

    function utmText(lat, lon) {
        var band = Coordinates.latitudeBand(lat);
        if (!band) return "UTM kapsamı dışında";
        var zone = Coordinates.utmZone(lat, lon);
        var epsg = (lat >= 0 ? 32600 : 32700) + zone;
        var utmCrs = QfCoordinateReferenceSystemUtils.fromDescription("EPSG:" + epsg);
        var p = projectedPoint(lon, lat, utmCrs);
        if (!isFinite(Number(p.x)) || !isFinite(Number(p.y))) return "Koordinat dönüştürülemedi";
        return Coordinates.formatUtm(zone, band, Number(p.x), Number(p.y));
    }

    function setTapped(lat, lon) {
        if (!Coordinates.inBounds(lat, lon)) return;
        tappedLatitude = lat;
        tappedLongitude = lon;
        tappedUtm = utmText(lat, lon);
        tappedValid = true;
    }

    function pointToTarget(lat, lon) {
        if (!Coordinates.inBounds(lat, lon)) {
            notify("Hedef koordinatı geçersiz.");
            return;
        }
        targetLatitude = lat;
        targetLongitude = lon;
        targetUtm = utmText(lat, lon);
        targetDetails = lat.toFixed(7) + ", " + lon.toFixed(7);
        targetValid = true;
        updateNavigation();
    }

    function copyText(value) {
        platformUtilities.copyTextToClipboard(value);
        notify("Koordinat kopyalandı");
    }

    function goToTarget() {
        if (!targetValid) return;
        try {
            var p = projectedPoint(targetLongitude, targetLatitude, qgisProject.crs);
            canvas.mapSettings.center = p;
            tappedValid = false;
            inputPopup.close();
            notify("Harita hedefe ortalandı.");
        } catch (e) {
            notify("Harita hedefe götürülemedi: " + e);
        }
    }

    function parseInput() {
        var result = Coordinates.parse(coordinateInput.text);
        if (!result.ok) { interpretation = result.error; notify(result.error); return; }
        try {
            var lat, lon;
            if (result.kind === 'utm') {
                var epsg = (result.hemisphere === 'N' ? 32600 : 32700) + result.zone;
                var sourceCrs = QfCoordinateReferenceSystemUtils.fromDescription('EPSG:' + epsg);
                var p = QfGeometryUtils.reprojectPoint(
                            QfGeometryUtils.point(result.easting, result.northing), sourceCrs, wgs84());
                lat = Number(p.y);
                lon = Number(p.x);
                if (result.band && result.band !== Coordinates.latitudeBand(lat)) {
                    interpretation = "UTM dilimi/bandı, hesaplanan enlemle uyuşmuyor; kontrol edin.";
                    notify(interpretation);
                    return;
                }
            } else {
                lat = result.lat;
                lon = result.lon;
            }
            if (!Coordinates.inBounds(lat, lon)) {
                interpretation = 'Koordinat dönüştürülemedi veya kapsam dışında.';
                notify(interpretation);
                return;
            }
            pointToTarget(lat, lon);
            interpretation = result.note + (result.ambiguous ? ' — farklı dilimdeyse 37T gibi yazın.' : '');
            goToTarget();
        } catch (e) {
            interpretation = 'Koordinat çözümlenirken hata oluştu.';
            notify(interpretation);
        }
    }

    function updateNavigation() {
        if (!targetValid) return;
        var gps = iface.positioning();
        if (!gps || !gps.active || !gps.positionInformation) {
            navigationDetails = "Mesafe için QField GPS konumunu açın.";
            return;
        }
        var info = gps.positionInformation;
        if (!info.latitudeValid || !info.longitudeValid) {
            navigationDetails = "Geçerli GPS konumu bekleniyor.";
            return;
        }
        var result = Coordinates.distanceAndBearing(
                    Number(info.latitude), Number(info.longitude),
                    targetLatitude, targetLongitude);
        navigationDetails = Coordinates.meters(result.distance) + " • " +
                Math.round(result.bearing) + "° " + Coordinates.direction(result.bearing) +
                " (kuzeye göre, kuş uçuşu)";
    }

    Timer {
        interval: 1500
        running: root.targetValid
        repeat: true
        onTriggered: root.updateNavigation()
    }

    Connections {
        target: root.canvas
        function onClicked(point, type) {
            if (!root.tapEnabled || !point) return;
            // Only observe map taps: native layer identification stays enabled.
            try {
                var c = root.canvas.mapSettings.screenToCoordinate(point);
                var g = root.geoFromProject(Number(c.x), Number(c.y));
                root.setTapped(g.lat, g.lon);
            } catch (e) {
                // Do not interfere with QField's existing map interactions.
            }
        }
    }

    QfToolButton {
        id: pluginButton
        iconSource: QfTheme.getThemeVectorIcon("ic_geotag_white_24dp")
        iconColor: QfTheme.toolButtonColor
        bgcolor: QfTheme.toolButtonBackgroundColor
        round: true
        onClicked: inputPopup.open()
    }

    // Small bottom strip; does not intercept map taps anywhere else.
    Rectangle {
        id: tapStrip
        parent: iface.mainWindow().contentItem
        z: 1000
        visible: root.tappedValid && root.tapEnabled && !inputPopup.opened
        width: Math.min(parent.width - 20, 425)
        height: 102
        radius: 12
        color: "#f5f7f9"
        border.color: "#c8ced3"
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 103

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 8
            spacing: 1
            Text { text: "Dokunulan nokta · WGS84 UTM"; color: "#58616d"; font.pixelSize: 11 }
            RowLayout {
                Layout.fillWidth: true
                Text { text: root.tappedUtm; color: "#182533"; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true; elide: Text.ElideRight }
                Button { text: "Kopyala"; onClicked: root.copyText(root.tappedUtm) }
            }
            RowLayout {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                Button { text: "Hedef yap"; onClicked: { root.pointToTarget(root.tappedLatitude, root.tappedLongitude); root.tappedValid = false; inputPopup.open(); } }
                Button { text: "Kapat"; onClicked: root.tappedValid = false }
            }
        }
    }

    Popup {
        id: inputPopup
        parent: iface.mainWindow().contentItem
        z: 1001
        modal: false
        focus: true
        width: Math.min(parent.width - 24, 410)
        height: Math.min(parent.height - 30, 535)
        x: Math.round((parent.width - width) / 2)
        y: Math.round(Math.max(8, (parent.height - height) / 2))
        padding: 14
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        background: Rectangle { color: "#f5f7f9"; radius: 13; border.color: "#c8ced3" }
        contentItem: ColumnLayout {
            spacing: 9
            RowLayout {
                Layout.fillWidth: true
                Text { text: "Koordinat ve Hedef"; font.bold: true; font.pixelSize: 19; color: "#182533"; Layout.fillWidth: true }
                Button { text: "×"; onClicked: inputPopup.close() }
            }
            Text { text: "Koordinat gir"; font.bold: true; color: "#182533" }
            TextField {
                id: coordinateInput
                Layout.fillWidth: true
                placeholderText: "37T 663840 4525972"
                selectByMouse: true
                inputMethodHints: Qt.ImhNoPredictiveText
                onAccepted: root.parseInput()
            }
            Text {
                text: "Enlem/boylam, 37T UTM, EPSG:32637 veya DMS"
                wrapMode: Text.WordWrap
                color: "#596573"; font.pixelSize: 11
                Layout.fillWidth: true
            }
            Button { text: "Koordinata git ve hedef yap"; Layout.fillWidth: true; onClicked: root.parseInput() }
            Text {
                text: root.interpretation
                visible: text.length > 0
                wrapMode: Text.WordWrap
                color: "#7d4e15"; font.pixelSize: 12
                Layout.fillWidth: true
            }
            Rectangle { Layout.fillWidth: true; height: 1; color: "#ccd2d7" }
            Text { text: "Hedef"; font.bold: true; color: "#182533" }
            Text { text: root.targetValid ? root.targetUtm : "Hedef seçilmedi"; font.pixelSize: 16; color: "#182533"; font.bold: true }
            Text { text: root.targetDetails; font.pixelSize: 12; color: "#596573" }
            Text { text: root.navigationDetails; font.pixelSize: 12; color: "#182533"; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            RowLayout {
                Layout.fillWidth: true
                Button { text: "Haritada göster"; enabled: root.targetValid; Layout.fillWidth: true; onClicked: root.goToTarget() }
                Button { text: "Kopyala"; enabled: root.targetValid; onClicked: root.copyText(root.targetUtm) }
                Button { text: "Sil"; enabled: root.targetValid; onClicked: { root.targetValid = false; root.targetDetails = "Hedef seçilmedi"; root.navigationDetails = "Hedef belirlenince GPS mesafesi burada görünür."; } }
            }
            CheckBox {
                text: "Haritaya dokununca UTM göster"
                checked: root.tapEnabled
                onToggled: { root.tapEnabled = checked; if (!checked) root.tappedValid = false; }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(pluginButton);
        console.log("Koordinat ve Hedef 0.1.1 yuklendi");
    }
}
